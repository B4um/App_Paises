package com.example.tela2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tela2.R;


public class MainActivity extends AppCompatActivity {
    EditText txtNumero;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNumero = (EditText) findViewById(R.id.txtNumero);
        btnSalvar = (Button) findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paises();
            }
        });
    }

    public void paises(){
        Integer Numero = Integer.parseInt(txtNumero.getText().toString());
        switch (Numero){
            case 1:
                Toast.makeText(this,"Rússia – 17.098.242 km²",Toast.LENGTH_SHORT).show();
                break;

            case 2:
                Toast.makeText(this,"Canadá – 9.984.670 Km²",Toast.LENGTH_SHORT).show();
                break;

            case 3:
                Toast.makeText(this,"China – 9.596.960 Km²",Toast.LENGTH_SHORT).show();
                break;

            case 4:
                Toast.makeText(this,"Estados Unidos – 9.833.517 Km²",Toast.LENGTH_SHORT).show();
                break;

            case 5:
                Toast.makeText(this,"Brasil – 8.510.345 Km²",Toast.LENGTH_SHORT).show();
                break;

            case 6:
                Toast.makeText(this,"Austrália – 7.692.024 km2",Toast.LENGTH_SHORT).show();
                break;

            case 7:
                Toast.makeText(this,"Índia – 3.287.590 km2",Toast.LENGTH_SHORT).show();
                break;

            case 8:
                Toast.makeText(this,"Argentina – 2.780.400 km2",Toast.LENGTH_SHORT).show();
                break;

            case 9:
                Toast.makeText(this,"Cazaquistão – 2.724.900 km2",Toast.LENGTH_SHORT).show();
                break;

            case 10:
                Toast.makeText(this,"Argélia – 2.381.741 km2",Toast.LENGTH_SHORT).show();
                break;

            case 11:
                Toast.makeText(this,"República Democrática do Congo – 2.344.858 km2",Toast.LENGTH_SHORT).show();
                break;

            case 12:
                Toast.makeText(this," Arábia Saudita  – 2.149.690 km2",Toast.LENGTH_SHORT).show();
                break;

            case 13:
                Toast.makeText(this,"México – 1.964.375 km2",Toast.LENGTH_SHORT).show();
                break;

            case 14:
                Toast.makeText(this,"Indonésia – 1.904.569 km2",Toast.LENGTH_SHORT).show();
                break;

            case 15:
                Toast.makeText(this,"Sudão – 1.886.068 km2",Toast.LENGTH_SHORT).show();
                break;

            case 16:
                Toast.makeText(this,"Líbia – 1.759.540 km2",Toast.LENGTH_SHORT).show();
                break;

            case 17:
                Toast.makeText(this,"Irã – 1.628.750 km2",Toast.LENGTH_SHORT).show();
                break;

            case 18:
                Toast.makeText(this,"Mongólia – 1.564.116 km2",Toast.LENGTH_SHORT).show();
                break;

            case 19:
                Toast.makeText(this,"Peru – 1.285.216 km2",Toast.LENGTH_SHORT).show();
                break;

            case 20:
                Toast.makeText(this,"Chade – 1.284.000 km2",Toast.LENGTH_SHORT).show();
                break;

            default:
                Toast.makeText(this,"Digite apenas números entre 1 e 20",Toast.LENGTH_SHORT).show();
        }
    }
}